<html>
<head>
<style>
body { background-image:
       url("sky-2483934_960_720");
	  background-repeat: no-repeat;
	 background-size: cover;
	 color: black;
	 }
.details {
	font-family : cursive;
	font-size :15px;
	margin : 0px 250px 0 50px;
	
}
.pot {
	margin-top:100px;margin-left:250px;
}
</style>
</head>
<body>
<?php
session_start();
$id=$_GET['id'];
$img=$_GET['img'];
$_SESSION['image']=$img;
require "a1.php";
$sql = "SELECT * FROM  hardware_details where modid=$id";
$result = mysqli_query($link, $sql);
echo '<table>';
echo '<tr>';
echo '<td>';
if (mysqli_num_rows($result) > 0) 
{
    echo '<div class="pot">';
	echo '<img src="'.$img.'" width=300 height=350 />';echo '<br>';
	?> <br><form action="addcart.php?id=<?php echo $id;?>&pro=smartphones" method="POST" >
    Quantity : <input align="right" input type="number" name="qty" size="50" value="1" >
   <input type="submit" value="Add to Cart">
     <?php
	echo '</div>';
	echo '</td>';
	echo '<td>';
	
	echo '<h3>   Hardware Details   </h3>';
	$row = mysqli_fetch_assoc($result);
    
	    echo '<div class="details">';
		echo "Model Colour : " . $row["Colour"]. "<br>Internal Storage : " . $row["Int_storage"];
		echo "<br>RAM : ".$row["RAM"]."<br>Front Camera : ".$row["Front_cam"]."<br>Rear Camera : ".$row["Rear_cam"];
        echo "<br>Display Size(inch) : ".$row["Disp_size"];
		echo '</div>';
}
$sql1 = "SELECT * FROM  software_details where modid=$id";
$result1 = mysqli_query($link, $sql1);
if (mysqli_num_rows($result1) > 0) 
{
   echo '<h3>Software Details</h3>';
   $row = mysqli_fetch_assoc($result1);
		echo '<div class="details">';
		echo "Version : " . $row["version"]. "<br>Processor : " . $row["cpu"];
		echo "<br>Clock Speed : ".$row["clockspeed"];
        echo '</div>';
		
}
echo '</td>';
echo '</tr>';
echo '</tr>';
?>
   
</body>
</html>
