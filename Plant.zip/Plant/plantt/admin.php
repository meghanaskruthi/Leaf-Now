 <?php
require 'a1.php';
if(isset($_POST['adminid'])&&isset($_POST['password']))
{
$search_name=$_POST['adminid'];
$password=$_POST['password'];
if(!empty($search_name)&&!empty($password))
{	$query="SELECT * FROM admin WHERE Admin_id='$search_name' AND Password='$password'";
	$query_run = mysqli_query($link,$query);
	if($query_run)
	{	
	 $query_num_rows=mysqli_num_rows($query_run);
		if($query_num_rows==0)
		{
          echo 'Invalid Details';
		}
		else
		{	
		 header('Location: http://localhost/Plant/plantt/ex1.php'); 
		}
    }else{
	   echo 'error';
	}
}
}
?>
<html>
<head>
<style type="text/css">
body {
background-image:url("signinpage.jpg");
 background-repeat: no-repeat;
	 background-size: 50% 100%;
color: #000000;
font-family: Cursive;
}
a { text-decoration: none }

form {
	  margin : 250px 0 0 750px;
	  font-family: Cursive;
	  font-size: 20px;
}

input[type=submit] {
	 height: 2.5em;
}
</style>

</head>
<body>
<form action="admin.php" method="POST">

Admin ID :  <input align="center"input type="text" name="adminid" size="50" maxlength="25" placeholder="  Enter Admin-ID  " ><br><br><br>

Password : <input type="password" name="password" size="50" maxlength="20"placeholder="  Enter password" ><br><br>

<input type="submit"value="Submit">
</form>
</body>
</html>