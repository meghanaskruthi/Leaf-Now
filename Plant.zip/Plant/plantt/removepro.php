<html>
<body>
<?php
$Plant_Id=$_GET['id'];
$pro=$_GET['pro'];
require "a1.php";
$s1="DELETE FROM $pro WHERE Plant_Id=$Plant_Id ";
$r1=mysqli_query($link,$s1);
if($r1)
{
   header('Location: http://localhost/htdocs/Plant/plantt/updrem.php');
}
else {
	   echo 'Cant help!!!';
}
?>
</body>
</html>