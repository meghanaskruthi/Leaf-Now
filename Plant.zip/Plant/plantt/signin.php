<?php
require 'a1.php';
if(isset($_POST['submit']))
{
	$cust_name=($_POST['cust_name']);
	$ph_no=($_POST['ph_no']);
	$address=$_POST['address'];
	$password=$_POST['password'];
	$password1=$_POST['password1'];
	if($password==$password1)
	{
		$s1=substr($cust_name,0,3);
		$s1.=substr($ph_no,8,9);
		$sql="INSERT INTO customer (cust_id,cust_name,ph_no,address,password) VALUES ('$s1','$cust_name',$ph_no,'$address','$password')";
		print "custname:$cust_name<p>p:$ph_no<p>a:$address<p>$password<p>p:$password1</blockquote></center>";
		
		$res=mysqli_query($link,$sql);
		
		if($res)
		{
		 session_start();
		 $_SESSION['cust_id']=$s1;
		 $_SESSION['cust_name']=$cust_name;
		  header('Location: http://localhost/Plant/plantt/custid.php'); 
		
	    }
	
	    else
	    {
		
		echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
	
	    }

    }
	else
	{
		echo 'password incorrect';
	}
}

?>
<!doctype>
<html>
<head>
<style type="text/css">
body {
background-image:url("signinpage.jpg");
 background-repeat: no-repeat;
	 background-size: 50% 100%;

font-family: Cursive;
}
a { text-decoration: none }

form {
	  margin : 40px 0 0 750px;
	  font-family: Cursive;
	  font-size: 20px;
}
h1 {
	 margin :95px 0 0 690px;
	 color : black;
}
input[type=submit] {
	 height: 2.5em;color : black;
}
</style>
</head>
<body>
<h1>SIGN-UP</h1>
<form method="post" action="signin.php" >
<strong>Name :</strong><p><input type="text" name="cust_name" size="35" required color = white></p>
<strong>Phone Number :</strong>
<p><input type="tel" name="ph_no" maxlength="10" pattern="[1-9]{1}[0-9]{9}" title="Only digits are allowed"></p>
<strong>Address :</strong>
<p><input type="text" name="address" size="50"></p>
<strong>Password :</strong>
<p><input type="password" name="password" size="10"></p>
<strong>Re-enter the Password :</strong>
<p><input type="password" name="password1" size="10"></p>
<p><input type="submit" name="submit" value="Submit"></p>
</form>

</body>
</html>