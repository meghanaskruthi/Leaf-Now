<html>
<head>
<style>
body { background-image:
       url("pexels-photo-261628");
	  background-repeat: no-repeat;
	 color: black;
	 }
</style>
</head>
<?php
 session_start();
 require "a1.php";
 $custid=$_SESSION['cust_id'];
 $sql="DELETE FROM cart WHERE custid='$custid'";
 $res=mysqli_query($link,$sql);
 if($res) {
	 echo "CART IS EMPTY";
	 header('Location: http://localhost/htdocs/ec.php');
 }
?>
</head>