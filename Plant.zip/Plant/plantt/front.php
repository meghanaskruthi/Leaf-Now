<html>
<head>
<style >
body { background-image:
       url("FrontPage.jpg");
	  background-repeat: no-repeat;
	 background-size: cover;
	 color: black;
	 }
p  {
      font-family: Imprint MT Shadow;
      font-size: 300%;
	  text-align:center;
	 }
a {
	   color: white;
	  text-decoration:none;
	  font-family: cursive;
	  padding-left: 175px;
	  font-size: 20px;
	  
}
.my {
	 font-family: cursive;
	 font-size:20px;
	 padding-left:750px;
}
</style>
</head>
<body> 
<br><br>

<p> Welcome To Plant <br>
   Store</p>

<div class="my">
Get Your Orders at Your Door Step 
</div>
<br>
<a href="signin.php"><em>SIGNUP</em></a>
<br><br>
<br>
<a href="login.php"><em>LOGIN</em></a>

</body>
</html>