<html>
<head>
<style>
body { background-image:
       url("all.jpg");
	  background-repeat: no-repeat;
	 background-size: cover;
	 color: black;
	 }
.details {
	font-family : cursive;
	font-size :20px;
	margin : 0px 0 0 50px;
}
.polarid {
	margin : 0 0 50px 250px;
}
.anc {
	margin : 0px 0px 0px 1200px;
}
ul {
	list-style-type: none;
    margin: 50px 0 0 0;
    padding-left:200px;
    overflow: hidden;
    background-color: #333;
}
li {
    float: left;
}
li a {
       display: inline-block;
       color: white;
       text-align: center;
       padding: 14px 30px;
       text-decoration: none;
}
li a:hover {
             background-color: #111;
}

</style>
</head>
<body>
<ul>
<li><a href="allaccess.php">HOME</a></li>
<li><a href="cart.php">YOUR CART</a></li>
<li><a href="orders.php">YOUR ORDERS</a></li>
<li><a href="login.php">LOG OUT</a></li>
</ul>

<?php
require "a1.php";
$sql = "SELECT * FROM plantflowerw";
$result = mysqli_query($link, $sql);
if (mysqli_num_rows($result) > 0) 
{
     echo '<table>';
	 while($row = mysqli_fetch_assoc($result))	
   {
        $pname=$row["Plant_name"];$pid=$row["Plant_Id"];$price=$row["price"];	
		$a=$row['Age'];
		echo '<br>';
		echo '<tr>';echo '<td>';$img=$row['userImage'];
		echo '<div class="polarid">';
		echo '<img src="'.$row['userImage'].'" width=250 height=300 />';
		?><br><form action="addcartc.php?id=<?php echo $id;?>&pro=plantflower" method="POST" >
        Quantity : <input align="right" input type="number" name="qty" size="50" value="1" >
        <input type="submit" value="Add to Cart">
        <?php 
		echo '</div>';
		echo '</td>';
		
	    $qty=$row["quantity"];
		if($qty!=0)
		{	 
	      echo '<td>';
		  echo '<div class="details">';
		  echo 'Plant Name : '.$pname.'<br>Plant Id : '.$[pid].'<br>Price : '.$price.'<br>
		  echo '</div>'; 
		  echo '</td>';
		  echo '</tr>';
		}
		else 
		{
			echo '<td><div class="details">Out Of Stock!!!</div></td></tr>';
		}
	    
	}echo '</table>';
} else {
    echo "0 results";
}
?>
</body>
</html>
