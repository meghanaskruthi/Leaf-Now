<?php
session_start();
$custid=$_SESSION['cust_id'];
require "a1.php";
$sql = "SELECT * FROM cart WHERE custid='$custid'";
$result = mysqli_query($link, $sql);
$rows=mysqli_num_rows($result);
echo $rows;
if (mysqli_num_rows($result) > 0) 
{
    while($row = mysqli_fetch_assoc($result))
	{
		echo '<br>'.$row['Plant_Id'];
	}
}
?>