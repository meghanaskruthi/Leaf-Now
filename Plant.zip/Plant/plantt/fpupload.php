<?php
require 'a1.php';
error_reporting(E_WARNING);
if(isset($_FILES['userImage']['tmp_name']))
{
	$qty=$_POST['qty'];
	$Plant=$_POST['Plant_Name'];
	$PlantId=$_POST['Plant_Id'];
	$Age=$_POST['Age'];
	$price=$_POST['price'];
	if(count($_FILES)>0)
	{
	 if(is_uploaded_file($_FILES['userImage']['tmp_name'])) 
	 {
		 $imgData=addslashes(file_get_contents($_FILES['userImage']['tmp_name']));
		move_uploaded_file($_FILES["userImage"]["tmp_name"],"Pictures/PF". $_FILES["userImage"]["name"]);
		$lc=$_FILES["userImage"]["name"];
	      $q1="INSERT INTO plantflower (Plant_name,Plant_Id,price,Age,quantity,userImage) VALUES('$Plant','$PlantId',$price','$Age',$qty,$lc)";
    	$r1=mysqli_query($link,$q1);
		echo "ERROR: Could not able to execute . " . mysqli_error($link);
	     $id=mysqli_insert_id($link);
     if($r1)
        {
              echo 'Uploaded Successfully';
           
        }
        else
         
           echo 'Nothing uploaded';
	  
        
		  }
    }
}	
?>
<html>
<head>
<style type="text/css">
body {
background-image:url("admin.jpg");
 background-repeat: no-repeat;
	 background-size: 50% 100%;
color: #000000;
font-family: Cursive;
}
a { text-decoration: none }

form {
	  margin : 0 0 0 750px;
	  font-family: Cursive;
	  font-size: 20px;
}
h1 {
	 margin : 0 0 0 650px;
}
input[type=submit] {
	 height: 2.5em;
}

</style>
</head>
<body>


<form method="post" action="fpupload.php" enctype="multipart/form-data">
<table border =0>

<br><br><br>
<tr><td><h2>Upload Features : Plant With Flowers</h2></td><tr>
<tr>
<td>Plant Name :</td><td><input type="text" name="Plant_Name"></td>
</tr>


<tr>
<td>Plant Id :</td><td><input type="text" name="Plant_Id"></td>
</tr>

<tr>

<td>Age :</td><td><input type="text" name="Age"></td>
</tr>

<tr>

<td>Price :</td><td><input type="text" name="price"></td>
</tr>

<tr>
<td>Quantity :</td><td><input type="text" name="qty"></td>
</tr>


<tr>
<td>Select the image : <input type="file" name='userImage' value="upload"></td>
</tr>

<tr>
<td><input type="submit" name="submit" value="submit"></td>
</tr>

</form>
</table>
</body>
</html>
