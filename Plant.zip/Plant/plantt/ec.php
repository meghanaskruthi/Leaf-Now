<html>
<head>
<style>
body { background-image:
       url("images (17)");
	  background-repeat: no-repeat;
	  color: black;
	  margin : 175px 0 0 120px;
	  font-family :cursive;
	 }
	 a {
		 text-decoration :none;
	 }
</style>
</head>
<body>
<h2>CART IS EMPTY</h2>
<a href="showall.php"><em>Want to add items to cart???</em></a>
</body>
</html>