<html>
<head>
<style>
body { background-image:
       url("");
	  background-repeat: no-repeat;
	 background-size: cover;
	 color: black;
	 }
ul { list-style-type:none;
     margin: 0;
	 padding: 0;
     width : 200px;
	 background-color : #4CAF50;
	 color : white;
	 height: 30%;
	 position : fixed;
	 }
h1 {
	margin :0 0 0 250px;
}
	 table {
	   margin:0 0 0 250px;
}
li a { display: block;
padding:8px 16px;
text-decoration:none;
color :white;
}
a {
	margin: 0 0 0 10px;
	text-decoration: none;
}
</style>
</head>
<body>
<a href="ex1.php">BACK</a>
<ul>
<li><br><a href="#plantflower">PlantWithFlowers</a></li>
<li><a href="#plantflowerw">PlantWithoutFlowers</a></li>
<li><a href="#PlantNew">ShowPlants</a></li>
<li><a href="ex1.php">BACK</a></li>
</ul>
<?php updrem("plantflower"); ?><br><br><h1>Plant With Flower</h1>
<?php updrem("plantflowerw"); ?><br><br><h1>Plant Without Flower</h1>
<?php updrem("PlantNew"); ?><br><br><h1>New Plants</h1>
<?php

function updrem($pro)
{
require "a1.php";
$sql = "SELECT * FROM $pro";
$result = mysqli_query($link, $sql);
if (mysqli_num_rows($result) > 0) 
{
?>
<table border="1" cellpadding="10">
<tr><th>Plant Name</th><th>Plant Id</th><th>Quantity</th><th>Age in Days</th><th>Price</th></tr>
<?php while($row=mysqli_fetch_array($result))
	{?><tr>
<td><?php echo $row['Plant_name'];?></td><td><?php echo $row['Plant_Id'] ?></td>
<td><?php echo $row['price'];?></td><td><?php echo $row['Age'];?></td><td><?php echo $row['quantity'];?></td>

	
<?php } } }?>
</table>
</body>
</html>
