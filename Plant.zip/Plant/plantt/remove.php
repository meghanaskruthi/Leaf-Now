<?php
session_start();
require "a1.php";
$Plant_Id=$_GET['id'];
$pro=$_GET['pro'];
$custid=$_SESSION['cust_id'];
$s1="DELETE FROM cart WHERE Plant_Id=$Plant_Id AND custid='$custid' AND pro='$pro'";
$r1=mysqli_query($link,$s1);
if($r1)
{
   header('Location: http://localhost/htdocs/Plant/plantt/cart.php');
}
else {
	   echo 'Cant help!!!';
}
?>