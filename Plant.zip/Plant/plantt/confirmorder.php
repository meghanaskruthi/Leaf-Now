<html>
<head>
<style>
.final {
	margin : 0 0 0 0
}
</style>
</head>
<body>
<fieldset>
<div class="final">
<h1>Your Order is Placed</h1>
<br><br>
<p><h2>Order Details</h2></p>
<?php
session_start();
require "a1.php";
$custid=$_SESSION['cust_id'];
$total=$_GET['total'];$odate=date('Y-m-d');
$date=date('Y-m-d',strtotime(' +2 days'));
$sql="INSERT INTO order_details (cust_id,price,EXPECTED_DELIVERY,ORDDATE) VALUES ('$custid',$total,'$date','$odate')";
$res=mysqli_query($link,$sql);
$oid=mysqli_insert_id($link);
?>
<strong>Date : <?php $nd=date('d-m-Y', strtotime( $odate )); echo $nd;?></strong><br><br>
<strong>Order ID : <?php echo $oid?></strong><br>
<table cellpadding="10" cellspacing="1" border="1">
<tbody>
<tr>
<th style="text-align:left"><strong>Items</strong></th>
<th style="text-align:centre"><strong>Quantity</strong></th>
<th style="text-align:right"><strong>Price</strong></th>
<th style="text-align:right"><strong>GST (5%)</strong></th>
</tr>
<?php 
$s4="SELECT * FROM cart WHERE custid='$custid'";
$r4=mysqli_query($link,$s4);
while($row4=mysqli_fetch_array($r4))
{
?>
<tr>
<td style="text-align:left;border-bottom:#FOFOFO 1px solid;"><?php echo $row4['Plant_name'];?></td>
<td style="text-align:centre;border-bottom:#FOFOFO 1px solid;"><?php echo $row4['quantity'];?></td>
<td style="text-align:right;border-bottom:#FOFOFO 1px solid;"><?php $p1=$row4['quantity']*$row4['price']; echo $p1;?></td>
<td style="text-align:right;border-bottom:#FOFOFO 1px solid;"><?php $p2=$p1*0.05; echo $p2;?></td>
</tr>
<?php
}
?>
<tr>
<td colspan="2" align=right><strong>Total :</strong>
<td><?php echo "₹ ".$total;?></td>
<td><?php $p3=$total*0.05; echo "₹ ".$p3;?></td>
</tr>
<tr>
<td colspan="4" align=right><strong>Total Amount</strong><?php $p4=$total+$p3;echo " ₹ ".$p4;?></td>
</tr>
</tbody>
</table>
<br><br>
<?php 
 $tq="SELECT * FROM customer WHERE cust_id='$custid'";
 $rq=mysqli_query($link,$tq);
 $row=mysqli_fetch_array($rq);
 $cname=$row['cust_name'];$address=$row['address'];
 ?>
<h2>Delivery Details :</h2>
<br><strong>Customer Name : <?php echo $cname;?></strong>
<br><br><strong>Address : <?php echo $address;?></strong><br><br>
<strong>Expected Delivery: <?php $nd=date('d-m-Y', strtotime( $date )); echo $nd;?></strong>
<br><br>
<strong>Mode of Payment : Cash On Delivery (Cards also Accepted) </strong> 
<?php
if($res)
{
	$s1="SELECT * FROM cart WHERE custid='$custid'";
	$r1=mysqli_query($link,$s1);
	if(mysqli_num_rows($r1)>0)
	{
		while($row=mysqli_fetch_array($r1))
		{
			$pid=$row['Plant_Id'];
			$cq=$row['quantity'];
			$pro=$row['Plant_name'];
			$s2="SELECT * FROM $pro WHERE Plant_Id=$pid";
			$r2=mysqli_query($link,$s2);
			$srow=mysqli_fetch_array($r2);
	}
    $s4="DELETE FROM cart WHERE custid='$custid'";
			$r4=mysqli_query($link,$s4);
}	
?>
<br><br>
<button onclick="window.print();">Print</button><br><br>
<a href="login.php"><input type="submit" value="LOGOUT"></a>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</div>
</fieldset>
</body>
</html>