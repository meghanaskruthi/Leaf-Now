<html>
<head></head>
<body>
<?php 
$pro=$_GET['pro'];
$Plant_Id=$_GET['id'];
require "a1.php";
if(isset($_POST['update']))
{
	if(isset($_POST['price']))
	{
		$price=$_POST['price'];
		$sql="UPDATE  $pro SET price=$price WHERE Plant_id=$Plant_Id";
		$res=mysqli_query($link,$sql);
		if($res) {
			header('Location: http://localhost/htdocs/Plant/plantt/updrem.php');
		}
			
	}
	if(isset($_POST['quantity']))
	{
		$qty=$_POST['quantity'];
		$sql="UPDATE  $pro SET quantity=$qty WHERE Plant_Id=Plant_Id";
		$res=mysqli_query($link,$sql);
		if($res) {
			header('Location: http://localhost/htdocs/Plant/plantt/updrem.php');
		}
			
	}
	
}
?>
</body>
</html>