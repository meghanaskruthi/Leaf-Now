<html>
<head>
<style>
body { background-image:
       url("all.jpg");
	  background-repeat: no-repeat;
	 background-size: cover;
	 color: black;
	 }
.details {
	font-family : cursive;
	font-size :20px;
	margin : 0px 250px 0 50px;
}
.my {
	 font-size :40px;
	 font-familty : cursive;
	 font-weight:bold;
	 margin-left : 500px;
}
.tab {
	  margin-left : 450px;
}
.txt-heading{    
	padding: 10px 10px;
    border-radius: 2px;
    color: #FFF;
    font-size:30px;
	font-family:cursive;
	background: #6aadf1;
	margin-bottom:10px;
    padding-left:550px
	}
#btnEmpty {
	background-color: #ffffff;
    border: #FFF 1px solid;
    padding: 1px 10px;
    color: #ff0000;
    font-size: 0.8em;
    float: right;
    text-decoration: none;
    border-radius: 4px;
}
#shopping-cart {margin-bottom:30px;
}
.mt {
	margin-left :450px;
	text-decoration : none;
	font-family : cursive;
	font-size :20px;
}
a {
	text-decoration : none;
}
ul {
	list-style-type: none;
    margin: 50px 0 0 0;
    padding-left: 200px;
    overflow: hidden;
    background-color: #333;
}
li {
    float: left;
}
li a {
       display: inline-block;
       color: white;
       text-align: center;
       padding: 14px 30px;
       text-decoration: none;
}
li a:hover {
             background-color: #111;
}
</style>
</head>
<body>
<ul>
<li><a href="allaccess.php">HOME</a></li>
<li><a href="cart.php">YOUR CART</a></li>
<li><a href="orders.php">YOUR ORDERS</a></li>
<li><a href="login.php">LOG OUT</a></li>
</ul>
</style>
<head>
<body>
<br><br>
<br>
<?php 
 require "a1.php";
 session_start();
 $cid=$_SESSION['cust_id'];
 $total=0;
?>
<div class="tab">
<table cellpadding="10" cellspacing="1" border="1">
<tbody>
<tr>
<th style="text-align-left"><strong>Plant Name</strong></th>
<th style="text-align:right"><strong>Plant ID</strong></th>>
<th style="text-align:right"><strong>Quantity</strong></th>
<th style="text-align:right"><strong>Price</strong></th>
<th style="text-align:right"><strong>Action</strong></th>
</tr>
<?php 
$sql="SELECT * FROM cart WHERE custid='$cid'";
$res=mysqli_query($link,$sql);
while($row=mysqli_fetch_array($res))
{
?>
<tr>
<td style="text-align:left;border-bottom:#FOFOFO 1px solid;" ><?php echo $row['Plant_name'];?></td>
<td style="text-align:right;border-bottom:#FOFOFO 1px solid;" ><?php echo $row['Plant_Id'];?></td>
<td style="text-align:left;border-bottom:#FOFOFO 1px solid;" ><?php echo $row['quanity'];?></td>
<td style="text-align:right;border-bottom:#FOFOFO 1px solid;" ><?php echo $row['price'];?></td>
<td style="text-align:right;border-bottom:#FOFOFO 1px solid;" >
<a href="remove.php?id=<?php echo $row['Plant_Id'];?>&pro=<?php echo $row['Plant_name'];?>">Remove</a></td>
</tr>
<?php 
$total=$total+($row['quantity']*$row['price']);
}
?>
<tr>
<td colspan="5" align=right><strong>Total : </strong><?php echo "₹ ".$total;?></td>
</tr>
</tbody>
</table>
</div>
<br>
<div class="mt">
<a href="empty.php">Empty Cart</a><br><br>
<a href="allaccess.php">Add more elements??</a><br><br>
<a href="confirmorder.php?total=<?php echo $total;?>">Place the order</a>
</div>
</body>
</html>
