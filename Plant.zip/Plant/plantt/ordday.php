<html>
<head>
<style>
ul {
	list-style-type: none;
    margin: 50px 0 0 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
li {
    float: left;
}
li a {
       display: inline-block;
       color: white;
       text-align: center;
       padding: 14px 30px;
       text-decoration: none;
}
li a:hover {
             background-color: #111;
}
body { background-image:
       url("all.jpg");
	  background-repeat: no-repeat;
	 background-size: cover;
	 color: black;
	 }
form { 
       margin: 200px 0 0 500px;
}
</style>
</head>
<body>
<ul>
<li><a href="vieworders.php">ALL ORDERS</a></li>
<li><a href="ordday.php">ORDER OF A DAY</a></li>
<li><a href="ex1.php">BACK</a></li>
</ul><br>
<form method="POST" action="ordday.php">
Select the date : <input type="date" name="dte" />
<br><br>
<input type="submit" name="submit" value="View orders" />
</form>
<?php
require "a1.php";
if(isset($_POST['submit']))
{
  $dte=$_POST['dte'];
  $sql = "SELECT `cust_id`, `price`, `ORD_ID`, `EXPECTED_DELIVERY`, `ORDDATE` FROM `order_details` WHERE ORDDATE='$dte' ";
$result = mysqli_query($link, $sql);
if (mysqli_num_rows($result) > 0) 
{ $tamount=0;
?>
<table border="1" cellpadding="10">
<tr><th>Order-Id</th><th>Customer-ID</th><th>Total</th></tr>
<?php while($row=mysqli_fetch_array($result))
	{?><tr>
<td><?php echo $row['ORD_ID'];?></td><td><?php echo $row['cust_id'] ?></td>
<td><?php echo $row['price'];?></td></tr>
<?php $tamount=$tamount+$row['price']; } echo '</table>'; 
?>Total Amount :<?php echo $tamount;}
else echo "Oops!! There are no orders...";
}
?>
</body>
</html>