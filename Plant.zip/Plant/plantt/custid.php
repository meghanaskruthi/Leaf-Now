
<html>
<head>
<style>
body { background-image:
       url("signinpage.jpg");
	   margin :299px 0 0 299px;
	  background-repeat: no-repeat;
	 background-size: 50% 100% ;
	 color: black;
	 }
a {
	   color: black;
	  text-decoration:none;
	  font-family: cursive;
	  padding-left: 750px;
	  font-size: 20px;
	  
}
p  {
      font-family: cursive;
      font-size: 150%;
	  margin :300px 0 0 399px;
	 }
</style>
</head>
<body>
<?php
session_start();
	$cname=$_SESSION['cust_name'];$cid=$_SESSION['cust_id'];	
?>
<p>Hey <?php echo " ".$cname."!!<br>         Your Customer-ID is ".$cid."<br>       Use this in future."; ?></p>
<br><br>
<a href="login.php">OK :)</a>
</body>
</html>