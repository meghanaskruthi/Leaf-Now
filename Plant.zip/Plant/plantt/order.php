
<?php
session_start();
require "a1.php";
$custid=$_SESSION['cust_id'];
$price=$_GET['total'];
$date=date('Y-m-d',strtotime(' +2 days'));
$sql="INSERT INTO order_details (cust_id,price,EXPECTED_DELIVERY) VALUES ('$custid',$price,'$date')";
$res=mysqli_query($link,$sql);
if($res)
{
	$s1="SELECT * FROM cart WHERE custid='$custid'";
	$r1=mysqli_query($link,$s1);
	if(mysqli_num_rows($r1)>0)
	{
		while($row=mysqli_fetch_array($r1))
		{
			$mid=$row['modid'];
			$cq=$row['qty'];
			$s2="SELECT * FROM plantflower WHERE Plant_Id=$pid";
			$r2=mysqli_query($link,$s2);
			$srow=mysqli_fetch_array($r2);
			$sq=$srow['quantity'];
			$s3="UPDATE plantflower SET quantity=$sq-$cq WHERE Plant_Id=$pid";
			$r3=mysqli_query($link,$s3);
			$s4="DELETE FROM cart WHERE custid='$custid'";
			$r4=mysqli_query($link,$s4);
		}
	}
}
	
?>