<html>
<head>
<style>
ul {
	list-style-type: none;
    margin: 50px 0 0 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
li {
    float: left;
}
li a {
       display: inline-block;
       color: white;
       text-align: center;
       padding: 14px 30px;
       text-decoration: none;
}
li a:hover {
             background-color: #111;
}
body { background-image:
       url("all.jpg");
	  background-repeat: no-repeat;
	 background-size: cover;
	 color: black;
	 }
table {
	    margin: 20px 0 0 350px;
}
</style>
</head>
<body>
<ul>
<li><a href="vieworders.php">ALL ORDERS</a></li>
<li><a href="ordday.php">ORDER OF A DAY</a></li>
<li><a href="ex1.php">BACK</a></li>
</ul>
<?php
require "a1.php";
$sql = "SELECT * FROM order_details ORDER BY ORD_ID DESC";
$result = mysqli_query($link, $sql);
if (mysqli_num_rows($result) > 0) 
{
?>
<table border="1" cellpadding="10">
<tr><th>Order-Id</th><th>Customer-ID</th><th>Ordered-Date</th><th>Total</th><th>Status</th></tr>
<?php while($row=mysqli_fetch_array($result))
	{?><tr>
<td><?php echo $row['ORD_ID'];?></td><td><?php echo $row['cust_id'] ?></td>
<td><?php $nd=date('d-m-Y', strtotime( $row['ORDDATE'] )); echo $nd;?></td>
<td><?php echo $row['price'];?></td>
<td><?php 
$now=date('Y-m-d');
$ord=$row['ORDDATE'];
$date=date_create($ord);
date_add($date,date_interval_create_from_date_string('1 days'));
$ord1=date_format($date,'Y-m-d');
$ord1;
if($now==$ord)
	echo 'Packed';
else if($now==$ord1)
	  echo 'Shipped';
 else echo 'Delivered';
?></td>
</tr>	
<?php }  }?>
</body>
</html>
			 