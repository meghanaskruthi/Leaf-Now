<?php
$cust_name='Kavana';
$ph_no='9844493320';
$s1=substr($cust_name,0,3);
		$s1.=substr($ph_no,7,9);
		echo $s1;
?>

