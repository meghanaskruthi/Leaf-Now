<?php
require 'a1.php';

if(isset($_POST['custid'])&&isset($_POST['password']))

{
$search_name=$_POST['custid'];
$password=$_POST['password'];
if(!empty($search_name)&&!empty($password))
{

	$query="SELECT cust_id, password FROM customer WHERE cust_id = '$search_name'AND password ='$password'";	 
	$query_run = mysqli_query($link,$query);
	
	if($query_run)
	{	
		
		$query_num_rows=mysqli_num_rows($query_run);
		if($query_num_rows==0)
		{
	
			echo '<strong>Invalid password OR UserName</strong>';
			
		
		}
		
	
		else
		{	
		   session_start();
		   $_SESSION['cust_id']=$search_name;
		   header('Location: http://localhost/Plant/plantt/allaccess.php');
		}
	
	

	}else{
	
		echo "ERROR: Could not able to execute . " . mysqli_error($link);
	
			echo 'error';
	
	}
}
}
?>
<html>

<head>

<style type="text/css">
body {
background-image:url("signinpage.jpg");
 background-repeat: no-repeat;
	 background-size: 50% 100%;
color: #000000;
font-family: Cursive;
}
a { text-decoration: none }

form {
	  margin : 250px 0 0 750px;
	  font-family: Cursive;
	  font-size: 20px;
}

input[type=submit] {
	 height: 2.5em;
}
</style>

</head>

<body>

<form action="login.php" method="POST">

<strong>Customer ID :</strong>
<p><input type="text" name="custid" size="35" placeholder=" Enter the Customer-ID" ></p>
<strong>Password :</strong>
<p><input type="password" name="passwor" size="50" maxlength="20"placeholder="  Enter password" ></p>

<input type="submit"value="Submit">
</form>
</body>
</html>