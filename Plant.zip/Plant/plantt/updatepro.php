<html>
<head>
<style>
body { background-image:
       url("all.jpg");
	  background-repeat: no-repeat;
	 background-size: cover;
	 color: black;
	 }
.my {
	   font-size: 30px;
	   font-family:"Comic Sans MS Header";
	   margin: 100px 0 0 500px
}
input[type=Update] {
	 height: 2.5em;
}
</style>
<body>
<?php
$Plant_Id=$_GET['id'];
$pro=$_GET['pro'];
require "a1.php";
$sql="SELECT * FROM $pro WHERE Plant_Id=$Plant_Id";
$res=mysqli_query($link,$sql);
$row=mysqli_fetch_array($res);
$PLant_Id=$row['Plant_Id'];$Plant_name=$row['Plant_name'];
$price=$row['price'];$quantity=$row['quantity'];
?>
<div class="my">
<form action="update.php?pro=<?php echo $pro;?>&id=<?php echo $Plant_Id;?>" method="POST">
<strong>Plant ID : <?php echo $Plant_Id; ?> </strong><br><br>
<strong>Plant Name :<?php echo $Plant_name; ?></strong><br><br>
<strong>Price : <input type="text" name="price" placeholder="<?php echo $price; ?>"><br><br>
<strong>Quantity : <input type="text" name="quantity" placeholder="<?php echo $quantity;?>"><br><br>
<input type="submit" name="update" value="Update">
</div>
</body>
</html>