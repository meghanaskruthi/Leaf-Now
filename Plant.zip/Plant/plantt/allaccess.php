<html>
<head>
</head>
<style>
h1 { 
     font-family: Imprint MT Shadow;
      font-size: 300%;
	 margin : 50px 0 0 450px;
}
body { background-image:
       url("all.jpg");
	  background-repeat: no-repeat;
	 background-size: cover;
	 color: black;
	 }
	 
</style>
<body>
<h1>ALL PRODUCTS </h1>
<br><br><br>
<a href="showall.php"><img src="flowers.jpg" width="300" height="300" border="2"></a>
<a href="showflowerw.php"><img src="plant.jpg" width="300" height="300" border="2"></a>
<a href="show.php"><img src="show.jpg" width="300" height="300" border="2"></a>
<br>

</body>
</html>