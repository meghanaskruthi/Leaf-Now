<?php
$error='not connected';
$host='localhost';
$user='root';
$password='root';
$my_sql='plant';
$link = mysqli_connect($host,$user,$password,$my_sql) or die($error);
?>