<html>
<head>
<style>
body {
background-image:url("sky-2483934_960_720");
 background-repeat: no-repeat;
	 background-size: cover;
color: #000000;
}
ul {
	list-style-type: none;
    margin: 50px 0 0 0;
    padding-left: 200px;
    overflow: hidden;
    background-color: #333;
}
li {
    float: left;
}
li a {
       display: inline-block;
       color: white;
       text-align: center;
       padding: 14px 30px;
       text-decoration: none;
}
li a:hover {
             background-color: #111;
}
table {
	    margin: 20px 0 0 450px;
}
</style>
</head>
<body>
<ul>
<li><a href="allaccess.php">HOME</a></li>
<li><a href="cart.php">YOUR CART</a></li>
<li><a href="orders.php">YOUR ORDERS</a></li>
<li><a href="login.php">LOG OUT</a></li>
</ul>
<?php
session_start();
require "a1.php";
$cust_id=$_SESSION['cust_id'];
$sql = "SELECT * FROM order_details WHERE cust_id='$cust_id'";
$result = mysqli_query($link, $sql);
if (mysqli_num_rows($result) > 0) 
{
?>
<table border="1" cellpadding="10">
<tr><th>Order-Id</th><th>Ordered-Date</th><th>Total</th><th>Status</th></tr>
<?php while($row=mysqli_fetch_array($result))
	{?><tr>
<td><?php echo $row['ORD_ID'];?></td>
<td><?php $nd=date('d-m-Y', strtotime( $row['ORDDATE'] )); echo $nd;?></td>
<td><?php echo $row['price'];?></td>
<td><?php 
$now=date('Y-m-d');
$ord=$row['ORDDATE'];
$date=date_create($ord);
date_add($date,date_interval_create_from_date_string('1 days'));
$ord1=date_format($date,'Y-m-d');
$ord1;
if($now==$ord)
	echo 'Packed';
else if($now==$ord1)
	  echo 'Shipped';
 else echo 'Delivered';
?></td>
</tr>	
<?php }
  }
  else echo "NO ORDERS";
?>

</table>
</body>
</html>
			 