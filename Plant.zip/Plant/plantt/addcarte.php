<html>
<head>
<style>
body {
background-image:url("all.jpg");
 background-repeat: no-repeat;
	 background-size: cover;
color: #000000;
font-family: Cursive;
font-size:25px;
}
.my {
	margin :200px 0 0 190px;
  
	}
a { text-decoration: none; 
  }
.u {
	 margin :0px 0 0 210px;
 }
</style>
</head>
<body>
<?php
session_start();
require "a1.php"; 
$cust_id=$_SESSION['cust_id'];
$id=$_GET['id'];$pro=$_GET['pro'];
$qty=$_POST['qty'];
$s1="SELECT * FROM cart where custid='$cust_id' AND pro='$pro' AND Plant_Id=$id";
$r1=mysqli_query($link,$s1);
if(mysqli_num_rows($r1)==0)
{
	$sql = "SELECT * FROM $pro where Plant_Id=$id";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
	$Plant_name=$row['Plant_name'];$price=$row['price'];$dq=$row['quantity'];
	if($qty<=$dq) {
	$s1="INSERT INTO cart (Plant_Id,cust_id,price,Plant_name,qty,pro) VALUES ($id,'$cust_id',$price,'$Plant_name',$qty,'$pro')";
	$r1=mysqli_query($link,$s1);
    echo '<div class="my">';  
    echo 'ADDED!!!<br>';	
	echo '<a href="allaccess.php">ADD MORE ELEMENTS TO CART??</a>';
	echo '</div>';
	}
	else {
		echo '<div class="my">';
		echo "Only ".$dq." items are available <br>         Enter less";
		$img=$_SESSION['image'];
	    echo "<br><a href='show.php?id=$id'>Go BACK</a>";    
	     echo '</div>';
	}
}
else {
$sql = "SELECT * FROM $pro where Plant_did=$id";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
	$oq=$row['quantity'];
$s1="SELECT * FROM cart WHERE Plant_Id=$id AND cust_id='$cust_id' AND pro='$pro'";
$res=mysqli_query($link,$s1);
if($res)
{
 $row=mysqli_fetch_assoc($res);
 $nq=$row['qty'];
 $t=$nq+$qty;
 if($oq<$t) {
	 $dif=$oq-$nq;
	 if($dif!=0)
	 { echo 'Only '.$dif.' items are available enter less'; }
 else {
	 echo 'Out of stock';
 }
      echo "<br><a href='show.php?id=$id'>Go BACK</a>";    
 }
 else {
	  $upq="UPDATE cart SET qty=$qty+$nq WHERE PLant_Id=$id AND cust_id='$cust_id' AND pro='$pro'";
	  if(mysqli_query($link,$upq))
	  {
		echo '<div class="my">';
		echo 'ADDED!!!';
		echo '<br><br><a href="allaccess.php">ADD MORE ELEMENTS TO CART??</a>';
	     echo '</div>';
	  }
	  else
	  {
		  echo 'nope!!!!';
	  }
	 
 }
}
else
{ 
 echo "opfailed";
}
}
?>
<br>
<div class="u">
<a href="cart.php">CART</a>
</div>
</body>
</html>
