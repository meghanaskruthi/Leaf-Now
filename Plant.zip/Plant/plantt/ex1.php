<html>
<head>
<style type="text/css">
body {
background-image:url("admin.jpg");
 background-repeat: no-repeat;
	 background-size: 50% 100%;
color: #000000;
font-family: Cursive;
}
a { text-decoration: none; 
    color: #000000;
  }

form {
	  margin : 250px 0 0 750px;
	  font-family: Cursive;
	  font-size: 30px;
}
</style>
</head>
<body>
<form>
<a href="viewall.php">View All Products</a><br><br>
Add a new Product
<select onchange="la(this.value)">
<option disabled selected>Select the product...</option>
<option value="fpupload.php">PlantWithFlowers</option>
<option value="wpupload.php">PlantWithountFlowers/</option>
<option value="chupload.php">NewPlants</option><br><br>
<option value=""></option></select><br><br>
<a href="updrem.php">Update/Remove Product</a><br><br>
<a href="vieworders.php">View Orders</a><br><br>

</form>
</body>
</html>
<script>
 function la(src)
 {
	 window.location=src;
 }
 </script>
