<?php
require 'a1.php';
error_reporting(E_WARNING);
if(isset($_FILES['userImage']['tmp_name']))
{
	$qty=$_POST['qty'];
	$image=$_POST['userImage'];
	$comp=$_POST['company_name'];
	$modname=$_POST['model_name'];
	$price=$_POST['price'];
	$war=$_POST['war'];
	$cap=$_POST['cap'];
	$iocr=$_POST['iocr'];
	if(count($_FILES)>0)
	{
	 if(is_uploaded_file($_FILES['userImage']['tmp_name'])) 
	 {
		 $imgData=addslashes(file_get_contents($_FILES['userImage']['tmp_name']));
		move_uploaded_file($_FILES["userImage"]["tmp_name"],"photos/" . $_FILES["userImage"]["name"]);
		$lc="photos/". $_FILES["userImage"]["name"];
	      $q1="INSERT INTO powerbanks (companyname,model_name,price,warranty,mobimg,quantity,capacity,iocr) 
		  VALUES('$comp','$modname',$price,'$war','$lc',$qty,'$cap','$iocr')";
    	  
		$r1=mysqli_query($link,$q1);
	     if($r1)
		 {
			 echo 'uploaded';
		 }
		 else {
        
           echo 'Nothing uploaded';
	       
        
		  }
    }

	}	
	}
?>
<html>
<head>
<style type="text/css">
body {
background-image:url("pexels-photo-257937");
 background-repeat: no-repeat;
	 background-size: cover;
color: #000000;
font-family: Cursive;
}
a { text-decoration: none }

form {
	  margin : 250px 0 0 750px;
	  font-family: Cursive;
	  font-size: 25px;
}
input[type=submit] {
	 height: 2.5em;
}
</style>
</head>
<body>
<form method="post" action="pbupload.php" enctype="multipart/form-data">
<table border =0>
<tr>
<td>Company Name :</td><td><input type="text" name="company_name"></td>
</tr>
<tr>
<td>Model Name :</td><td><input type="text" name="model_name"></td>
</tr>
<tr>
<td>Price :</td><td><input type="text" name="price"></td>
</tr>
<tr>
<td>Quantity :</td><td><input type="text" name="qty"></td>
</tr>
<tr>
<td>Warranty :</td><td><input type="text" name="war"></td>
</tr>
<tr>
<td>Capacity :</td><td><input type="text" name="cap"></td>
</tr>
<tr>
<td>Input Output Current Rating :</td><td><input type="text" name="iocr"></td>
</tr>
<tr>
<td>Select the image : <input type="file" name='userImage' value="upload"></td>
</tr>
<tr>
<td><input type="submit" name="submit" value="submit"></td>
</tr>
</form>
</table>
</body>
</html>
